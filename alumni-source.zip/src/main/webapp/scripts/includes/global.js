$(document).ready(function(){
    document.body.style.zoom = 1.2;
});
